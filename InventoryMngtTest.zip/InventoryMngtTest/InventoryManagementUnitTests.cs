using Microsoft.VisualStudio.TestTools.UnitTesting;
using Inventory;

namespace Inventory
{
       [TestClass]
    public class InventoryManagementUnitTests
    {
        readonly StockController sc = new StockController();
        [TestMethod]
        public void AddItem()
        { 
            AddItem c = new AddItem("Jewellery", 56.00, 58.76);
            sc.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
        }

        [TestMethod]
        public void UpdateItemQuantity()
        {
           UpdateSoldQty c = new UpdateSoldQty("Jewellery", 300);
            sc.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
            Assert.AreEqual(c.QtyUpdated, 500);
        }

        [TestMethod]
        public void TestUpdateSoldQuantity()
        {
           UpdatePurchasedQty c = new UpdatePurchasedQty("Jewellery", 250);
            sc.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
            Assert.AreEqual(c.QtyUpdated, 200);
        }

        [TestMethod]
        public void UpdateSellingPrice()
        {
            UpdateSellingPrice c = new UpdateSellingPrice("Jewellery", 20);
            sc.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
            Assert.AreEqual(c.PriceUpdated, 20);
        }

        [TestMethod]
        public void TestDelete()
        {
            Delete c = new Delete("Goods");
            sc.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
        }

        [TestMethod]
        public void TestReport()
        {
            InventoryReport c = new InventoryReport();
            sc.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
        }

        [TestMethod]
        public void ProfitReport()
        {
            ProfitReport c = new ProfitReport();
            sc.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
        }
    }
}
