using Microsoft.VisualStudio.TestTools.UnitTesting;
using Inventory;

namespace Inventory
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestCreate()
        {
            StockController m = new StockController();
            Create c = new Create("Book", 10.50, 13.79);
            m.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
        }

        [TestMethod]
        public void TestUpdateBuy()
        {
            StockController m = new StockController();
            UpdateBuy c = new UpdateBuy("Book", 300);
            m.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
            Assert.AreEqual(c.QtyUpdated, 300);
        }

        [TestMethod]
        public void TestUpdateSell()
        {
            StockController m = null;
            UpdateSell c = new UpdateSell("Book1", 50);
            m.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
        }

        [TestMethod]
        public void TestDelete()
        {
            StockController m = null;
            Delete c = new Delete("Book1");
            m.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
        }

        [TestMethod]
        public void TestReport()
        {
            StockController m = null;
            Report c = new Report();
            m.Invoke(c);
            Assert.IsTrue(c.IsCompleted);
        }
    }
}
